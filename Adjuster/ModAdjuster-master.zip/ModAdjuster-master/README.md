# ModAdjuster
Framework for modifying content of Space Engineers mods on load.

To set this up, copy the Data folder into your mod.
Create definitions for blocks and blueprints to modify in the BlockDefinitions and BlueprintDefinitions files respectively.
