# SE-Water
Water Mod for Space Engineers

https://steamcommunity.com/sharedfiles/filedetails/?id=2200451495

This mod has official support for Draygo's Aerodynamics Mod, it is not required but with it you can get more accurate drag forces.

Join the discord to discuss suggestions and bugs you may experience:
https://discord.gg/GrPK8cB

Thanks ShadeStuff for creating a proper water and splash texture :)