﻿using Sandbox.ModAPI;
using VRage.Game;
using VRage.Game.Components;

namespace pepco.template
{
    public class EconomyComponent : MySessionComponentBase, ISessionComponent
    {
        public override void Init(MyObjectBuilder_SessionComponent sessionComponent)
        {
            MyAPIGateway.Utilities.ShowMessage("EconomyComponent", "Economy component initialized.");
        }

        public override void UpdateAfterSimulation()
        {
            // Logic for updating economy goes here
        }

        public void HandleCommand(string messageText, ref bool sendToOthers)
        {
            if (messageText.StartsWith("/pepco"))
            {
                var parameters = messageText.Split(' ');

                if (parameters.Length < 2)
                {
                    MyAPIGateway.Utilities.ShowMessage("EconomyMod", "Invalid command usage.");
                    sendToOthers = false;
                    return;
                }

                switch (parameters[1].ToLower())
                {
                    case "settax":
                        if (parameters.Length == 3)
                        {
                            float taxRate;
                            if (float.TryParse(parameters[2], out taxRate))
                            {
                                // Set tax rate logic
                                MyAPIGateway.Utilities.ShowMessage("EconomyMod", string.Format(EconomyTexts.TaxRateUpdated, taxRate));
                            }
                            else
                            {
                                MyAPIGateway.Utilities.ShowMessage("EconomyMod", "Usage: /pepco settax <rate>");
                            }
                        }
                        else
                        {
                            MyAPIGateway.Utilities.ShowMessage("EconomyMod", "Usage: /pepco settax <rate>");
                        }
                        break;

                    case "setinflation":
                        if (parameters.Length == 3)
                        {
                            float inflationRate;
                            if (float.TryParse(parameters[2], out inflationRate))
                            {
                                // Set inflation rate logic
                                MyAPIGateway.Utilities.ShowMessage("EconomyMod", string.Format(EconomyTexts.InflationRateUpdated, inflationRate));
                            }
                            else
                            {
                                MyAPIGateway.Utilities.ShowMessage("EconomyMod", "Usage: /pepco setinflation <rate>");
                            }
                        }
                        else
                        {
                            MyAPIGateway.Utilities.ShowMessage("EconomyMod", "Usage: /pepco setinflation <rate>");
                        }
                        break;

                    default:
                        MyAPIGateway.Utilities.ShowMessage("EconomyMod", "Unknown command.");
                        break;
                }

                sendToOthers = false; // Prevent sending the command to others
            }
        }

        void ISessionComponent.UnloadData()
        {
            // Clean up resources if necessary
        }

        protected override void UnloadData()
        {
            base.UnloadData();
            // Clean up additional resources if necessary
        }
    }
}
