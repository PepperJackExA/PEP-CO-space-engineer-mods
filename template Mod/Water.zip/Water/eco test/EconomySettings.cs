﻿using ProtoBuf;
using System.Xml.Serialization;

namespace pepco.template
{
    [ProtoContract]
    public class EconomySettings
    {
        [ProtoMember(5), XmlElement]
        public float TaxRate;

        [ProtoMember(10), XmlElement]
        public float InflationRate;

        public static readonly EconomySettings Default = new EconomySettings()
        {
            TaxRate = 0.1f,
            InflationRate = 0.02f,
        };
    }
}
