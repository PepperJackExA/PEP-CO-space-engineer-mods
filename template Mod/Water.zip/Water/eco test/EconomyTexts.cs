﻿namespace pepco.template
{
    public static class EconomyTexts
    {
        public static string ModChatName = "EconomyMod";
        public static string EconomyModVersion = "Economy Mod V{0} by PEPCO.";
        public static string TaxRateUpdated = "Tax rate updated to {0}%.";
        public static string InflationRateUpdated = "Inflation rate updated to {0}%.";
    }
}
