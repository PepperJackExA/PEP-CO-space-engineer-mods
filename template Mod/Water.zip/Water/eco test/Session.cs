﻿using Sandbox.Game.World;
using Sandbox.ModAPI;
using System;
using System.Collections.Generic;
using VRage.Game;
using VRage.Game.Components;

namespace pepco.template
{
    [MySessionComponentDescriptor(MyUpdateOrder.AfterSimulation)]
    public class Session : MySessionComponentBase
    {
        public static Session Instance;

        private readonly Dictionary<Type, ISessionComponent> _sessionComponents = new Dictionary<Type, ISessionComponent>();

        public Action UpdateAfterSimulationAction;
        public Action DrawAction;

        private EconomyComponent _economyComponent;

        public Session()
        {
            Instance = this;
        }

        public override void LoadData()
        {
            base.LoadData();

            _economyComponent = new EconomyComponent();
            AddComponent(_economyComponent);

            MyAPIGateway.Utilities.MessageEntered += OnMessageEntered;
        }

        private void OnMessageEntered(string messageText, ref bool sendToOthers)
        {
            _economyComponent.HandleCommand(messageText, ref sendToOthers);
        }

        public override void UpdateAfterSimulation()
        {
            UpdateAfterSimulationAction?.Invoke();
        }

        public override void Draw()
        {
            DrawAction?.Invoke();
        }

        public override void BeforeStart()
        {
            if (ModContext != null)
            {
                foreach (var componentPair in _sessionComponents)
                {
                    (componentPair.Value as MySessionComponentBase).ModContext = ModContext;
                    (componentPair.Value as MySessionComponentBase).BeforeStart();
                }
            }
        }

        protected override void UnloadData()
        {
            MyAPIGateway.Utilities.MessageEntered -= OnMessageEntered;

            foreach (var componentPair in _sessionComponents)
            {
                componentPair.Value.UnloadData();
            }

            Instance = null;
            base.UnloadData();
        }

        private void AddComponent<T>(T component) where T : MySessionComponentBase, ISessionComponent
        {
            _sessionComponents[typeof(T)] = component;

            UpdateAfterSimulationAction += component.UpdateAfterSimulation;
            DrawAction += component.Draw;
        }
    }
}
