﻿namespace pepco.template
{
    public interface ISessionComponent
    {
        void UnloadData();
    }
}
